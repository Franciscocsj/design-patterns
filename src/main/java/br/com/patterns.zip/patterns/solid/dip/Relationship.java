package main.java.br.com.study.patterns.solid.dip;

public enum Relationship {
    PARENT,
    CHILD,
    SIBILING
}
