package main.java.br.com.study.patterns.solid.isp;

import org.yaml.snakeyaml.scanner.Scanner;

public class Photocopier implements Printer, Scan {
    @Override
    public void print(Document d) {

    }

    @Override
    public void scan(Document d) {

    }
}
