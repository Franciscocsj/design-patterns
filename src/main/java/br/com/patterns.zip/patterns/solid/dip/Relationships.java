package main.java.br.com.study.patterns.solid.dip;


public class Relationships {


}
