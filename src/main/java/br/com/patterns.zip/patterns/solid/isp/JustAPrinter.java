package main.java.br.com.study.patterns.solid.isp;

public class JustAPrinter implements Printer{
    @Override
    public void print(Document d) {

    }
}
