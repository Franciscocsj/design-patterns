package main.java.br.com.study.patterns.solid.isp;

public interface MultiFunctionDevice extends Printer, Scan {
}
