package main.java.br.com.study.patterns.solid.isp;

public class Document {
}
