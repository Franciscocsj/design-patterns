package main.java.br.com.study.patterns.solid.ocp;

public enum Size {
    SMALL, MEDIUM, LARGE, YUGE
}
