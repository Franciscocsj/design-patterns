package main.java.br.com.study.patterns.solid.ocp;

public enum Color {
    RED, GREEN, BLUE
}
