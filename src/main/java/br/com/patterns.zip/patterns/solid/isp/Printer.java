package main.java.br.com.study.patterns.solid.isp;

public interface Printer {

    void print(Document d);
}
