package main.java.br.com.study.patterns.solid.isp;

public interface Scan {

    void scan(Document d);
}
