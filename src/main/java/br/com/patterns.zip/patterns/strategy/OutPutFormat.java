package main.java.br.com.study.patterns.strategy;

public enum OutPutFormat {
    MARKDOWN, HTML
}
